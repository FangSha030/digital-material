# KMP算法

> [!note] 知识点 4.2.2
> 所属章节：[[第4章 串]]

## 🏷️ 标签

#串 
#模式匹配 
#KMP算法 
#next数组 
#部分匹配值 

## 📖 知识解释

根据图4.2的匹配过程，在第三趟匹配中，i=7、j=5的字符比较，结果不等，于是又从i=4、j=1重新开始比较。然而，仔细观察会发现，i=4和j=1，i=5和j=1及i=6和j=1这三次比较都是不必进行的。从第三趟部分匹配的结果可知，主串的第4个、第5个和第6个字符是'b'、'c'和'a'（即模式串的第2个、第3个和第4个字符），因为模式串的第1个字符是'a'，所以无须再和

这三个字符进行比较，而只需将模式串向右滑动三个字符的位置，继续进行 i=7、j=2 时的比较即可。

在暴力匹配中，每趟匹配失败都是模式串后移一位再从头开始比较。而某趟已匹配相等的字符序列是模式串的某个前缀，这种频繁的重复比较相当于模式串不断地进行自我比较，这就是其低效率的根源。因此，可以从分析模式串本身的结构着手，若已匹配相等的前缀序列中有某个后缀正好是模式串的前缀，则可将模式串向后滑动到与这些相等字符对齐的位置，主串 i 指针无须回溯，并从该位置开始继续比较。而模式串向后滑动位数的计算仅与模式串本身的结构有关，而与主串无关（这里理解起来比较困难，没关系，带着这个问题继续往后看）。

## 1. 字符串的前缀、后缀和部分匹配值

要了解子串的结构，首先要弄清楚几个概念：前缀、后缀和部分匹配值。前缀指除最后一个字符以外，字符串的所有头部子串；后缀指除第一个字符外，字符串的所有尾部子串；部分匹配值则为字符串的前缀和后缀的最长相等前后缀长度。下面以'ababa'为例进行说明：

'a'的前缀和后缀都为空集，最长相等前后缀长度为0。

• 'ab'的前缀为{a}，后缀为{b}，{a}∩{b} = ∅，最长相等前后缀长度为0。

'aba'的前缀为{a,ab}，后缀为{a,ba}，{a,ab}∩{a,ba}={a}，最长相等前后缀长度为1。

`'abab'` 的前缀 {a, ab, aba} ∩ 后缀 {b, ab, bab} = {ab}，最长相等前后缀长度为 2。

`'ababa'`的前缀{a, ab, aba, abab}∩后缀{a, ba, aba, baba}={a, aba}，公共元素有两个，最长相等前后缀长度为3。

因此，字符串'ababa'的部分匹配值为00123。

这个部分匹配值有什么作用呢？

回到最初的问题，主串为 ababcabcacbab，子串为 abcac。

利用上述方法容易写出子串'abcac'的部分匹配值为00010，将部分匹配值写成数组形式，就得到了部分匹配值（Partial Match，PM）的表。

<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>编号</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>S</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>c</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>PM</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>0</td></tr></table>

下面用 PM 表来进行字符串匹配：

 $$  主串 \quad a\quad b\quad a\quad b\quad c\quad a\quad b\quad c\quad a\quad c\quad b\quad a\quad b $$

主串 a b a b c a b c a c b a b
子串 a b c

 $$ \begin{array}{cccc} 孑串 &a&b&c\end{array} $$

第一趟匹配过程：

发现 c 与 a 不匹配，前面的 2 个字符 'ab' 是匹配的，查表可知，最后一个匹配字符 b 对应的部分匹配值为 0，因此按照下面的公式算出子串需要向后移动的位数：

 $$  移动位数 = 已匹配的字符数 - 对应的部分匹配值 $$

因为2-0=2，所以将子串向后移动2位，如下进行第二趟匹配：

主串 a b a b c a b c a c b a b
子串 a b c a c

第二趟匹配过程：

发现 c 与 b 不匹配，前面 4 个字符 'abca' 是匹配的，最后一个匹配字符 a 对应的部分匹配值为 1，4-1=3，将子串向后移动 3 位，如下进行第三趟匹配：

主串 a b a b c a b c a c b a b
子串 a b c a c

第三趟匹配过程：

子串全部比较完成，匹配成功。整个匹配过程中，主串始终没有回退，所以 KMP 算法可以在  $ O(n+m) $ 的时间数量级上完成串的模式匹配操作，大大提高了匹配效率。

某趟发生失配时，若对应的部分匹配值为0，则表示已匹配相等序列中没有相等的前后缀，此时移动的位数最大，直接将子串首字符后移到主串当前位置进行下一趟比较；若已匹配相等序列中存在最大相等前后缀（可理解为首尾重合），则将子串向右滑动到和该相等前后缀对齐（这部分字符下一趟显然不需要比较），然后从主串当前位置进行下一趟比较。

## 2. KMP 算法的原理是什么

我们刚刚学会了怎样计算字符串的部分匹配值、怎样利用子串的部分匹配值快速地进行字符串匹配操作，但公式“移动位数 = 已匹配的字符数 - 对应的部分匹配值”的意义是什么呢？

如图4.3所示，当c与b不匹配时，已匹配'abca'的前缀a和后缀a为最长公共元素。已知前缀a与b、c均不同，与后缀a相同，因此无须比较，直接将子串移动“已匹配的字符数－对应的部分匹配值”，用子串前缀后面的元素与主串匹配失败的元素开始比较即可，如图4.4所示。

主串

图 4.3 失配后移动情况

主串

图 4.4 直接移动到合适位置

对算法的改进方法：

已知：右移位数 = 已匹配的字符数 - 对应的部分匹配值。

写成：Move = (j - 1) - PM[j - 1]。

使用部分匹配值时，每当匹配失败，就去找它前一个元素的部分匹配值，这样使用起来有些不方便，所以将PM表右移一位，这样哪个元素匹配失败，直接看它自己的部分匹配值即可。

将上例中字符串'abcac'的PM表右移一位，就得到了next数组：

<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>编号</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>S</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>c</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>next</td><td style='text-align: center; word-wrap: break-word;'>-1</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td></tr></table>

我们注意到：

1）第一个元素右移以后空缺的用-1来填充，因为若是第一个元素匹配失败，则需要将子串向右移动一位，而不需要计算子串移动的位数。

2）最后一个元素在右移的过程中溢出，因为原来的子串中，最后一个元素的部分匹配值是其下一个元素使用的，但显然已没有下一个元素，所以可以舍去。

这样，上式就改写为

 $$ Move=(j-1)-next[j] $$

相当于将子串的比较指针 j 回退到

 $$ \mathbf{j}=\mathbf{j}-\operatorname{Move}=\mathbf{j}-((\mathbf{j}-1)-\operatorname{next}[\mathbf{j}])=\operatorname{next}[\mathbf{j}]+1 $$

有时为了使公式更加简洁、计算简单，将 next 数组整体+1。

因此，上述子串的 next 数组也可以写成

<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>编号</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>S</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>c</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>next</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td></tr></table>

#### 命题追踪 KMP 匹配过程中指针变化的分析（2015）

最终得到子串指针变化公式 j=next[j]。在实际匹配过程中，子串在内存中是不会移动的，而是指针发生变化，画图举例只是为了让问题描述得更形象。 $ \uwave{\text{next[j]的含义是：当子串的第j个字符与主串发生失配时，跳到子串的next[j]位置重新与主串当前位置进行比较}} $。

如何推理 next 数组的一般公式？设主串为's₁s₂⋯sn'，模式串为'p₁p₂⋯pₘ'，当主串中第 i 个字符与模式串中第 j 个字符失配时，子串应向右滑动多远，然后与模式中的哪个字符比较？

假设此时应与模式串的第 k（k<j）个字符继续比较，则模式串中前 k-1 个字符的子串必须满足下列条件，且不可能存在 k'>k 满足下列条件：

 $$ p_{1}p_{2}\cdots p_{k-1}=p_{j-k+1}p_{j-k+2}\cdots p_{j-1} $$

若存在满足如上条件的子串，则发生失配时，仅需将模式串向右滑动至模式串的第 k 个字符和主串的第 i 个字符对齐，此时模式串中的前 k-1 个字符的子串必定与主串中第 i 个字符之前长度为 k-1 的子串相等，由此，只需从模式串的第 k 个字符与主串的第 i 个字符继续比较即可，如图 4.5 所示。

<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>主串</td><td style='text-align: center; word-wrap: break-word;'>$ s_{1} $</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>$ s_{i-k+1} $</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>$ s_{i-1} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{{s}_{i}} $</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>$ s_{n} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>子串</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>$ p_{1} $</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>$ p_{k-1} $</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>$ p_{j-k+1} $</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>$ p_{j-1} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{{p}_{j}} $</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>$ p_{m} $</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>右移</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>$ p_{1} $</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>$ p_{k-1} $</td><td style='text-align: center; word-wrap: break-word;'>$ p_{k} $</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>...</td><td style='text-align: center; word-wrap: break-word;'>$ p_{m} $</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

图4.5 模式串右移到合适位置（阴影对齐部分表示上下字符相等）

当模式串已匹配相等序列中不存在满足上述条件的子串时（可视为 k=1），显然应该将模式串右移 j-1 位，让主串的第 i 个字符和模式串的第 1 个字符进行比较，此时右移位数最大。

当模式串的第1个字符（j=1）与主串的第i个字符发生失配时，规定 next[1]=0 $ ^{} $。将模式串右移一位，从主串的下一个位置（i+1）和模式串的第1个字符继续比较。

通过上述分析可以得出 next 函数的公式:

 $$  next\left[j\right]=\left\{\begin{aligned}&0,&j=1\\&\max\left\{k\mid1<k<j 且 ^{\prime}p_{1}\cdots p_{k-1}^{\prime}=^{\prime}p_{j-k+1}\cdots p_{j-1}^{\prime}\right\},& 当此集合不空时 \\&1,& 其他情况 \end{aligned}\right. $$

上述公式不难理解，实际做题求 next 值时，用之前的方法也很好求，但要想用代码来实现，貌似难度还真不小，我们来尝试推理求解的科学步骤。

首先由公式可知

 $$  next\left[1\right]=0 $$

设 next[j]=k，此时 k 应满足的条件在上文中已描述。

此时 next  $ [j+1]= $？可能有两种情况：

(1)若  $ p_k = p_j $，则表明在模式串中

 $$ \mathbf{p}_{1}\cdots\mathbf{p}_{k-1}\mathbf{p}_{k}=\mathbf{p}_{j-k+1}\cdots\mathbf{p}_{j-1}\mathbf{p}_{j} $$

并且不可能存在  $ k' > k $ 满足上述条件，此时  $ next[j+1] = k+1 $，即

 $$  next\left[j+1\right]=next\left[j\right]+1 $$

(2) 若  $ p_k \neq p_j $，则表明在模式串中

 $$ \mathbf{p}_{1}\cdots\mathbf{p}_{k-1}\mathbf{p}_{k}\neq\mathbf{p}_{j-k+1}\cdots\mathbf{p}_{j-1}\mathbf{p}_{j} $$

此时可将求 next 函数值的问题视为一个模式匹配的问题。用前缀  $ p_1 \cdots p_k $ 去与后缀  $ p_{j-k+1} \cdots p_j $ 匹配，当  $ p_k \neq p_j $ 时，应将  $ p_1 \cdots p_k $ 向右滑动至以第 next [k] 个字符与  $ p_j $ 比较，若  $ p_{next[k]} $ 与  $ p_j $ 仍不匹配，则需要寻找长度更短的相等前后缀，下一步继续用  $ p_{next[next[k]]} $ 与  $ p_j $ 比较，以此类推，直到找到某个更小的  $ k' = next[next \cdots [k]] $（ $ 1 < k' < k < j $），满足条件

 $$ \mathbf{p}_{1}\cdots\mathbf{p}_{k},\mathbf{\Lambda}^{\prime}=\mathbf{p}_{j-k^{\prime}+1}\cdots\mathbf{p}_{j}, $$

则 next  $ [j+1]=k'+1 $。

也可能不存在任何  $ k' $ 满足上述条件，即不存在长度更短的相等前缀后缀，令 next  $ [j+1]=1 $。理解起来有一点费劲？下面举一个简单的例子。

图4.6 的模式串中已求得6个字符的 next 值，现求 next[7]，因为 next[6]=3，又  $ p_6 \neq p_3 $，则需比较  $ p_6 $ 和  $ p_1 $（因 next[3]=1），由于  $ p_6 \neq p_1 $，而 next[1]=0，因此 next[7]=1；求 next[8]，因  $ p_7 = p_1 $，则 next[8]=next[7]+1=2；求 next[9]，因  $ p_8 = p_2 $，则 next[9]=3。

<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>j</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td><td style='text-align: center; word-wrap: break-word;'>6</td><td style='text-align: center; word-wrap: break-word;'>7</td><td style='text-align: center; word-wrap: break-word;'>8</td><td style='text-align: center; word-wrap: break-word;'>9</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>模式串</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>c</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>next $ [j] $</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>?</td><td style='text-align: center; word-wrap: break-word;'>?</td><td style='text-align: center; word-wrap: break-word;'>?</td></tr></table>

图 4.6 求模式串的 next 值

通过上述分析写出求 next 值的程序如下：

void get_next(CString T,int next[]) {
    int i=1, j=0;
    next[1]=0;
    while(i<T.length) {
        if (j==0||T.ch[i]==T.ch[j]) {
            ++i; ++j;
            next[i]=j; //若p_i=p_j，则next[j+1]=next[j]+1
        }
        else
            j=next[j]; //否则令j=next[j]，循环继续
    }
}

计算机执行起来效率很高，但对于我们手工计算来说会很难。因此，当我们需要手工计算时，还是用最初的方法。

与 next 数组的求解相比，KMP 的匹配算法相对要简单很多，它在形式上与简单的模式匹配算法很相似。不同之处仅在于当匹配过程产生失配时，指针 i 不变，指针 j 退回到 next[j] 的位置并重新进行比较，并且当指针 j 为 0 时，指针 i 和 j 同时加 1。即若主串的第 i 个位置和模式串的第 1 个字符不等，则应从主串的第 i+1 个位置开始匹配。具体代码如下：

int Index_KMP(String S, String T, int next[])
{
    int i=1, j=1;
    while (i<=S.length && j<=T.length) {
        if (j==0 || S.ch[i]==T.ch[j]) {
            ++i; ++j; //继续比较后继字符
        }
        else
            j=next[j]; //模式串向右移动
    }
    if (j>T.length)
        return i-T.length; //匹配成功
    else
        return 0;
}

#### 命题追踪 KMP 匹配过程中比较次数的分析（2019）

尽管普通模式匹配的时间复杂度是  $ O(mn) $，KMP 算法的时间复杂度是  $ O(m+n) $，但在一般情况下，普通模式匹配的实际执行时间近似为  $ O(m+n) $，因此至今仍被采用。KMP 算法仅在主串与子串有很多“部分匹配”时才显得比普通算法快得多，其主要优点是主串不回溯。

## 📝 相关题目

### 选择题

**题目 4.2.2-1**（选择题）

设有两个串  $ S_{1} $ 和  $ S_{2} $，求  $ S_{2} $ 在  $ S_{1} $ 中首次出现的位置的运算称为（）。

- A. 求子串
- B. 判断是否相等
- C. 模式匹配
- D. 连接

> [!success]- 答案
> C

> [!tip]- 解析
> 求子串操作是从串 S 中截取第 i 个字符起长度为 l 的子串，A 错误。B、D 明显错误。

---

**题目 4.2.2-2**（选择题）

KMP 算法的特点是在模式匹配时，指示主串的指针()。

- A. 不会变大
- B. 不会变小
- C. 都有可能
- D. 无法判断

> [!success]- 答案
> B

> [!tip]- 解析
> 在 KMP 算法的比较过程中，主串不会回溯，所以主串的指针不会变小。

---

**题目 4.2.2-3**（选择题）

设主串的长度为 n，子串的长度为 m，则简单的模式匹配算法的时间复杂度为( ), KMP 算法的时间复杂度为( )。

- A. $ O(m) $
- B. $ O(n) $
- C. $ O(mn) $
- D. $ O(m+n) $

> [!success]- 答案
> C

> [!tip]- 解析
> 、D
> 
> 尽管实际应用中，一般情况下简单的模式匹配算法的时间复杂度近似为  $ O(m+n) $，但它的理论时间复杂度还是  $ O(mn) $。KMP 算法的时间复杂度为  $ O(m+n) $。

---

**题目 4.2.2-4**（选择题）

在 KMP 匹配中，用 next 数组存放模式串的部分匹配信息，当模式串位 j 与主串位 i 比较时，两个字符不相等，则 j 的位移方式是（）。

- A. j=0
- B. j=j+1
- C. j 不变
- D. j=next[j]

> [!success]- 答案
> D

> [!tip]- 解析
> 在 KMP 匹配中，当主串的第 i 个字符和模式串的第 j 个字符不匹配时，主串的位指针 i 不变，将主串的第 i 个字符与模式串的第 next[j] 个字符比较，即 j=next[j]。

---

**题目 4.2.2-5**（选择题）

在 KMP 匹配中，用 next 数组存放模式串的部分匹配信息，当模式串位 j 与主串位 i 比较时，两个字符不相等，则 i 的位移方式是（）。

- A. i=next[i]
- B. i 不变
- C. i=0
- D. i=i+1

> [!success]- 答案
> B

> [!tip]- 解析
> 在 KMP 匹配中，当主串的第 i 个字符和模式串的第 j 个字符不匹配时，主串位 i 不回溯。

---

**题目 4.2.2-8**（选择题）

串'ababaaababaa'的next数组为（）。

- A. -1,0,1,2,3,4,5,6,7,8,8,8
- B. -1,0,1,0,1,0,0,0,0,1,0,1
- C. -1,0,0,1,2,3,1,1,2,3,4,5
- D. -1,0,1,2,-1,0,1,2,1,1,2,3

---

**题目 4.2.2-10**（选择题）

【2015 统考真题】已知字符串 S 为 'abaabaabacacaabaabcc'，模式串 t 为 'abaabc'。采用 KMP 算法进行匹配，第一次出现“失配”（s[i]≠t[j]）时，i=j=5，则下次开始匹配时，i 和 j 的值分别是（ ）。

- A. i=1, j=0
- B. i=5, j=0
- C. i=5, j=2
- D. i=6, j=2

> [!success]- 答案
> C

> [!tip]- 解析
> 由题中“失配 s[i]≠t[j]时，i=j=5”，可知题中的主串和模式串的位序都是从0开始的（要注意灵活应变）。按照 next 数组生成算法，对于 t 有
> 
> <table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>编号</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>t</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>next</td><td style='text-align: center; word-wrap: break-word;'>-1</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td></tr></table>
> 
> 发生失配时，主串指针 i 不变，子串指针 j 回退到 next[j] 位置重新比较，当 s[i]≠t[j] 时，i=j=5，由 next 表得知 next[j]=next[5]=2（位序从 0 开始）。因此，i=5，j=2。

---

**题目 4.2.2-11**（选择题）

【2019 统考真题】设主串 T='abaabaabcabaabc'，模式串 S='abaabc'，采用 KMP 算法进行模式匹配，到匹配成功时为止，在匹配过程中进行的单个字符间的比较次数是()。

- A. 9
- B. 10
- C. 12
- D. 15

> [!success]- 答案
> B

> [!tip]- 解析
> 假设位序从0开始的，按照 next 数组生成算法，对于 s 有
> 
> <table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>编号</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>S</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>next</td><td style='text-align: center; word-wrap: break-word;'>-1</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td></tr></table>
> 
> 第一趟连续比较6次，在模式串的5号位和主串的5号位匹配失败，模式串的下一个比较位置为next[5]，即下一次比较从模式串的2号位和主串的5号位开始，然后直到模式串的5号位和主串的8号位匹配，第二趟比较4次，匹配成功。单个字符的比较次数为10次。
> 
> ### 二、综合应用题

---

### 综合应用题

**题目 4.2.2-1**（综合应用题）

在字符串模式匹配的 KMP 算法中，求模式的 next 数组值的定义如下：

 $$  next[j]=\left\{\begin{aligned}&0,&j=1\\&\max\{k\mid1<k<j 且 ^{\prime}p_{1}\cdots p_{k-1}^{\prime}=^{\prime}p_{j-k+1}\cdots p_{j-1}^{\prime}\},\\&1,& 其他情况 \end{aligned}\right.\quad 集合不为空 $$

1）当 $ j=1 $时，为什么要取next $ [1]=0 $？

2）为什么要取 $ \max\{k\} $，k 最大是多少？

3）其他情况是什么情况，为什么取 next[j]=1?

> [!tip]- 参考答案与解析
> 1）当模式串的第1个字符与主串的当前字符比较不相等时，next[1]=0，表示模式串应右移一位，主串当前指针后移一位，再和模式串的第1个字符进行比较。
> 
> 2）当主串的第 i 个字符与模式串的第 j 个字符失配时，主串 i 不回溯，则假定模式串的第 k 个字符与主串的第 i 个字符比较，k 值应满足条件  $ 1 < k < j $ 且  $ \mathbf{p}_{1} \cdots \mathbf{p}_{k-1} = \mathbf{p}_{j-k+1} \cdots \mathbf{p}_{j-1} $，即 k 为模式串的下次比较位置。k 值可能有多个，为了不使向右移动丢失可能的匹配，右移距离应该取最小，因为 j-k 表示右移的距离，所以取  $ \max\{k\} $。k 的最大值为 j-1。
> 
> 3）除上面两种情况外，发生失配时，主串指针 i 不回溯，在最坏情况下，模式串从第 1 个字符开始与主串的第 i 个字符比较。

---

**题目 4.2.2-2**（综合应用题）

设有字符串  $ S = 'aabaabaabaac' $， $ P = 'aabaac' $

1）求出P的next数组。

2）若 S 作主串，P 作模式串，试给出 KMP 算法的匹配过程。

> [!tip]- 参考答案与解析
> 1）P='aabaac'，按照 next 数组生成算法，对于 P 有：
> 
> ① 设 next[1]=0，next[2]=1。
> 
> <table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>编号</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td><td style='text-align: center; word-wrap: break-word;'>6</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>S</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>next</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>
> 
> ② j=3 时 k=next[j-1]=next[2]=1, 观察 S[j-1](S[2]) 与 S[k](S[1]) 是否相等, S[2]=a, S[1]=a, S[2]=S[1], 所以 next[j]=k+1=2。
> 
> ↓j-1=2
> 
> a a b a a c
> 
> a a b a a c
> 
> ↑k-1
> 
>  $$ \uparrow k=1 $$
> 
> ③ j=4 时 k=next[j-1]=next[3]=2，观察 S[j-1] (S[3]) 与 S[k] (S[2]) 是否相等，S[3]=b，S[2]=a，S[3]!=S[2]。
> 
>  $$ \begin{aligned}&\downarrow j-1=3\\ \downarrow a&a b a a c\\ a a b a a a c&c\\ \uparrow k=2&\end{aligned} $$
> 
> 此时 k=next[k]=1，观察 S[3]与 S[k] (S[1]) 是否相等，S[3]=b，S[1]=a，S[3]!=S[1]。k=next[k]=0，因为 k=0，所以 next[j]=1。
> 
> ↓j-1=3
> 
> a a b a a c
> 
> a a b a a c
> 
> ↑k=0
> 
> ④ j=5 时 k=next[j-1]=next[4]=1，观察 S[j-1] (S[4]) 与 S[k] (S[1]) 是否相等，S[4]=a，S[1]=a，S[4]=S[1]，所以 next[j]=k+1=2。
> 
>  $$ \begin{aligned}&\downarrow j-1=4\\a\quad&a\quad b\quad&a\quad&a\quad&c\\&a\quad&a\quad&b\quad&a\quad&a\quad&c\\&\uparrow k=1\end{aligned} $$
> 
> ⑤ j=6 时 k=next[j-1]=next[5]=2，观察 S[j-1] (S[5]) 与 S[k] (S[2]) 是否相等，S[5]=a，S[2]=a，S[5]=S[2]，所以 next[j]=k+1=3。
> 
> 最后的结果为
> 
> <table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>编号</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td><td style='text-align: center; word-wrap: break-word;'>6</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>S</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>next</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td></tr></table>
> 
> 也可以通过求部分匹配值表的方法来求 next 数组。
> 
> 2）利用 KMP 算法的匹配过程如下。
> 
> 第一趟：从主串和模式串的第1个字符开始比较，失配时 i=6, j=6。
> 
> <table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>主串</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{a} $</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>$ \underline{a} $</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td><td colspan="6"></td></tr></table>
> 
> 第二趟：next[6]=3，主串当前位置和模式串的第3个字符继续比较，失配时i=9，j=6。
> 
> <table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>主串</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{b} $</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td colspan="4"></td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{b} $</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td><td colspan="3"></td></tr></table>
> 
> 第三趟：next[6]=3，主串当前位置和模式串的第3个字符继续比较，匹配成功。
> 
> <table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>主串</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{b} $</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr><tr><td colspan="7"></td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{b} $</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>c</td></tr></table>
> 
> #### 归纳总结
> 
> 学习 KMP 算法时，应从分析暴力法的弊端入手，思考如何去优化它。实际上，已匹配相等的序列就是模式串的某个前缀，因此每次回溯就相当于模式串与模式串的某个前缀比较，这种频繁的重复比较是效率低的原因。这时，可从分析模式串本身的结构入手，以便得知当匹配到某个字符不等时，应该向后滑动到什么位置，即已匹配相等的前缀和模式串若首尾重合，则对齐它们，对齐部分显然无须再比较，下一步则是直接从主串的当前位置继续进行比较。
> 
> #### 思维拓展
> 
> 编程实现：模式串在主串中有多少个完全匹配的子串？注意，统考不会考 KMP 算法题。
> 
> ## 05

---

## 🔗 相关知识点

- [[简单的模式匹配算法|4.2.1 简单的模式匹配算法]]（共同标签：#串, #模式匹配）
- [[KMP算法的进一步优化|4.2.3 KMP算法的进一步优化]]（共同标签：#串, #KMP算法）

---
**返回：** [[第4章 串]] | [[数据结构 MOC]]
