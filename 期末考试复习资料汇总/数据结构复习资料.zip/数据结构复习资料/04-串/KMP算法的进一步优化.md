# KMP算法的进一步优化

> [!note] 知识点 4.2.3
> 所属章节：[[第4章 串]]

## 🏷️ 标签

#串 
#KMP算法 
#nextval数组 

## 📖 知识解释

前面定义的 next 数组在某些情况下尚有缺陷，还可以进一步优化。如图 4.7 所示，模式串 'aaaab' 在和主串 'aaabaaaab' 进行匹配时：

主串 a a a b a a a b
模式串 a a a a b
j 1 2 3 4 5
next[j] 0 1 2 3 4
nextval[j] 0 0 0 0 4

图 4.7 KMP 算法进一步优化示例

当 i=4、j=4 时，s₄跟 p₄（b≠a）失配，若用之前的 next 数组，则还需要进行 s₄与 p₃、s₄ 与 p₂、s₄ 与 p₁ 这 3 次比较。事实上，因为 p_{next[4]=3}=p₄=a、p_{next[3]=2}=p₃=a、p_{next[2]=1}=p₂=a，显然后面 3 次用一个和 p₄ 相同的字符跟 s₄ 比较毫无意义，必然失配。那么问题出在哪里呢？

问题在于不应该出现  $ p_j = p_{next[j]} $。理由是：当  $ p_j \neq s_j $ 时，下次匹配必然是  $ p_{next[j]} $ 跟  $ s_j $ 比较，若  $ p_j = p_{next[j]} $，则相当于拿一个和  $ p_j $ 相等的字符跟  $ s_j $ 比较，这必然导致继续失配，这样的比较毫无意义。若出现  $ p_j = p_{next[j]} $，则如何处理呢？

若出现  $ p_j = p_{next[j]} $，则需要再次递归，将 next[j] 修正为 next[next[j]]，直至两者不相等为止，更新后的数组命名为 nextval。计算 next 数组修正值的算法如下，此时匹配算法不变。

void get_nextval(CString T,int nextval[]) {
    int i=1, j=0;
    nextval[1]=0;
    while (i<T.length) {
        if (j==0||T.ch[i]==T.ch[j]) {
            ++i; ++j;
            if (T.ch[i]!=T.ch[j]) nextval[i]=j;
            else nextval[i]=nextval[j];
        }
    }
}

else
j=nextval[j];
}

KMP 算法对于初学者来说可能不太容易理解，读者可以尝试多读几遍本章的内容，并参考一些其他教材的相关内容来巩固这个知识点。

## 📝 相关题目

### 选择题

**题目 4.2.3-9**（选择题）

串'ababaaababaa'的nextval数组为（）。

- A. 0,1,0,1,1,2,0,1,0,1,0,2
- B. 0,1,0,1,1,4,1,1,0,1,0,2
- C. 0,1,0,1,0,4,2,1,0,1,0,4
- D. 0,1,1,1,0,2,1,1,0,1,0,4

> [!success]- 答案
> C

> [!tip]- 解析
> nextval 从 0 开始，可知串的位序从 1 开始。第一步，令 nextval[1]=next[1]=0。
> 
> <table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>编号</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td><td style='text-align: center; word-wrap: break-word;'>6</td><td style='text-align: center; word-wrap: break-word;'>7</td><td style='text-align: center; word-wrap: break-word;'>8</td><td style='text-align: center; word-wrap: break-word;'>9</td><td style='text-align: center; word-wrap: break-word;'>10</td><td style='text-align: center; word-wrap: break-word;'>11</td><td style='text-align: center; word-wrap: break-word;'>12</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>S</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>b</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>a</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>next</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>5</td><td style='text-align: center; word-wrap: break-word;'>6</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>nextval</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{1}{1} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{0} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{1} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{0} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{4} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{2} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{1} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{0} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{1} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{0} $</td><td style='text-align: center; word-wrap: break-word;'>$ \underline{4} $</td></tr></table>
> 
> 从 j=2 开始，依次判断  $ p_j $ 是否等于  $ p_{next[j]} $？若是则将 next[j] 修正为 next[next[j]]，直至两者不相等为止。由下述推理可知，答案选 C。
> 
> 第2步： $ p_2=b $、 $ p_{next[2]}=a $， $ p_2\neq p_{next[2]} $，nextval[2]=next[2]=1；
> 
> 第3步： $ p_3 = a $、 $ p_{next[3]} = a $， $ p_3 = p_{next[3]} $，nextval[3] = nextval[next[3]] = nextval[1] = 0；
> 
> 第4步： $ p_4=b $、 $ p_{next[4]}=b $， $ p_4=p_{next[4]} $，nextval[4]=nextval[next[4]]=nextval[2]=1；
> 
> 第5步： $ p_5 = a $、 $ p_{next[5]} = a $， $ p_5 = p_{next[5]} $，nextval[5] = nextval[next[5]] = nextval[3] = 0；
> 
> 第6步： $ p_6 = a $、 $ p_{next[6]} = b $， $ p_6 \neq p_{next[6]} $，nextval[6] = next[6] = 4；
> 
> 第7步： $ p_7 = a $、 $ p_{next[7]} = b $， $ p_7 \neq p_{next[7]} $，nextval[7] = next[7] = 2；
> 
> 第8步： $ p_{8}=b $、 $ p_{next[8]}=b $， $ p_{8}=p_{next[8]} $，nextval[8]=nextval[next[8]]=nextval[2]=1；
> 
> 第9步： $ p_9 = a $、 $ p_{next[9]} = a $， $ p_9 = p_{next[9]} $，nextval[9] = nextval[next[9]] = nextval[3] = 0；
> 
> 第10步： $ p_{10}=b $、 $ p_{next[10]}=b $， $ p_{10}=p_{next[10]} $，nextval[10]=nextval[next[10]]=nextval[4]=1；
> 
> 第11步： $ p_{11}=a $、 $ p_{next[11]}=a $， $ p_{11}=p_{next[11]} $，nextval[11]=nextval[next[11]]=nextval[5]=0；
> 
> 第12步： $ p_{12}=a $、 $ p_{next[12]}=a $， $ p_{10}=p_{next[12]} $，nextval[12]=nextval[next[12]]=nextval[6]=4；
> 
> 在第5步的推理中， $ p_5 = p_{next[5]} = a $，按前面的讲解部分，应该继续让 $ p_3 $和 $ p_{next[3]} $比较（恰好 $ p_3 = p_{next[3]} = 1 $），注意到此时nextval[3]的值已存在，故直接将nextval[5]赋值为nextval[3]。
> 
> 对于一般情况，nextval 数组是从前往后逐步求解的，发生  $ p_j = p_{next[j]} $ 时，因为 nextval [next[j]] 早已求得，所以直接将 nextval[j] 赋值为 nextval[next[j]]。

---

## 🔗 相关知识点

- [[简单的模式匹配算法|4.2.1 简单的模式匹配算法]]（共同标签：#串）
- [[KMP算法|4.2.2 KMP算法]]（共同标签：#串, #KMP算法）

---
**返回：** [[第4章 串]] | [[数据结构 MOC]]
